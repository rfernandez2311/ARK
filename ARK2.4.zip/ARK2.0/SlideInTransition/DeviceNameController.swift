//
//  DeviceNameController.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/14/19.
//  Copyright © 2019 Gary Tokman. All rights reserved.
//

import UIKit



class DeviceNameController: UITableViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
    }
    
}
