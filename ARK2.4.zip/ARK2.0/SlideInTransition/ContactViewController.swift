//
//  ContactViewController.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/12/19.
//  Copyright © 2019 Gary Tokman. All rights reserved.
//

import UIKit
import Foundation
import TinyConstraints
import UserNotifications
import CoreBluetooth
import SVProgressHUD
import Toast_Swift

class ContactViewController: UIViewController {
    
    let transiton = SlideInTransition()
    var topView: UIView?
    @IBOutlet weak var btnSendinfo: UIButton!
    @IBOutlet weak var phoneView: UIView!
    @IBOutlet weak var carsizeView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        CommonFunctions.shared.makeButtonCornerRounds(button: self.btnSendinfo , cornerRadius: self.btnSendinfo.frame.size.height / 5)
//        CommonFunctions.shared.makeViewCornerRounds(view: self.phoneView , cornerRadius: self.phoneView.frame.size.height / 10)
//        CommonFunctions.shared.makeViewCornerRounds(view: self.carsizeView , cornerRadius: self.carsizeView.frame.size.height / 10)
        
        createShadow(view: phoneView)
        
        
       

        
    }

    
    
    func createShadow(view: UIView){
    
        view.layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        view.layer.shadowRadius = 4
        view.layer.shadowOpacity = 1
        view.layer.shadowOffset = CGSize(width: 10, height: 5)
    
        view.layer.cornerRadius  = 10
        
    }
    
    
    
    
    
    //////// buttonn function implementation//////////////////
    
    
    @IBAction func didTapMenu(_ sender: UIButton) {
        
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }
    
    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title
        
        topView?.removeFromSuperview()
        switch menuType {
            
        case .home:
            let HomeView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Home_VC_id") as! HomeViewController
            HomeView.view.frame = self.view.bounds
            self.view.addSubview(HomeView.view)
            
            
        case .contact:
            let ContactView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Contact") as! ContactViewController
            ContactView.view.frame = self.view.bounds
            self.view.addSubview(ContactView.view)
            
            
        case .settings:
            let SettingsView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Settings") as! SettingsViewController
            SettingsView.view.frame = self.view.bounds
            self.view.addSubview(SettingsView.view)
            
            //default:
            //   break
        }
    }
}

extension ContactViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}
