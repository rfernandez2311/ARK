//
//  SettingsViewController.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/12/19.
//  Copyright © 2019 Gary Tokman. All rights reserved.
//

import UIKit
import Foundation
import UserNotifications
import CoreBluetooth
import SVProgressHUD
import Toast_Swift

class SettingsViewController: UIViewController {
   
    let transiton = SlideInTransition()
    var topView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    //////// buttonn function implementation//////////////////
    
    
    @IBAction func didTapMenu(_ sender: UIButton) {
        
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }
    
    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title
        
        topView?.removeFromSuperview()
        switch menuType {
            
        case .home:
          let HomeView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Home_VC_id") as! HomeViewController
          HomeView.view.frame = self.view.bounds
          self.view.addSubview(HomeView.view)


        case .contact:
            let ContactView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Contact") as! ContactViewController
            ContactView.view.frame = self.view.bounds
            self.view.addSubview(ContactView.view)
            
            
        case .settings:
            let SettingsView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Settings") as! SettingsViewController
            SettingsView.view.frame = self.view.bounds
            self.view.addSubview(SettingsView.view)
        
        //default:
            //break
     
        }
    }
}

extension SettingsViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}
