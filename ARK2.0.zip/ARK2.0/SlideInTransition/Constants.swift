//
//  Constants.swift
//  ARK
//
//  Created by Kitlabs-M-0002 on 1/7/19.
//  Copyright © 2019 Kitlabs-M-0002. All rights reserved.
//

import UIKit

class Constants: NSObject {
    
    struct navigationTitles {
        static let userAgreement = "User Agreement"
        static let home = "Home"
        static let configuration = "Configuration"
    }
    
    
    struct carSize {
        static let small = "Small"
        static let medium = "Medium"
        static let large = "Large"
    }
    
    
    struct ErrorMessages {
        static let acceptTermsAndConditions = "Please accept Terms and Conditions"
    }

    static let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
    
    struct defaultsKey {
        static let isAgreementAccepted = "isAgreementAccepted"
    }
}
