//
//  ContactViewController.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/12/19.
//  Copyright © 2019 Gary Tokman. All rights reserved.
//

import UIKit
import Foundation
import TinyConstraints
import UserNotifications
import CoreBluetooth
import SVProgressHUD
import Toast_Swift

class ContactViewController: UIViewController {
    
    let transiton = SlideInTransition()
    var topView: UIView?
    @IBOutlet weak var btnSendinfo: UIButton!
    @IBOutlet weak var phoneView: UIView!
    @IBOutlet weak var carsizeView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        createShadow(button: btnSendinfo)

        createShadow1(view: phoneView)
        createShadow1(view: carsizeView)
        
        
       

        
    }
    func createShadow(button: UIButton){
        
        button.layer.cornerRadius  = 10
        
    }

    
    
    func createShadow1(view: UIView){
    
        view.layer.shadowColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        view.layer.shadowRadius = 10
        view.layer.shadowOpacity = 0.4
        view.layer.shadowOffset = CGSize(width: 2, height: 2)
        
        view.layer.cornerRadius  = 10
        
    }
    
    
    
    
    
    //////// buttonn function implementation//////////////////
    
    
    @IBAction func didTapMenu(_ sender: UIButton) {
        
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }
    
    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title
        
        topView?.removeFromSuperview()
        switch menuType {
            
        case .home:
            let HomeView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Home_VC_id") as! HomeViewController
            HomeView.view.frame = self.view.bounds
            self.view.addSubview(HomeView.view)
            
            
        case .contact:
            let ContactView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Contact") as! ContactViewController
            ContactView.view.frame = self.view.bounds
            self.view.addSubview(ContactView.view)
            
            
        case .settings:
            let SettingsView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Settings") as! SettingsViewController
            SettingsView.view.frame = self.view.bounds
            self.view.addSubview(SettingsView.view)
            
            //default:
            //   break
        }
    }
}

extension ContactViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}
