//
//  UserAgreement_VC.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/2/19.
//  Copyright © 2019 Raphael Fernandez. All rights reserved.
//

import UIKit
import FTIndicator
import Toast_Swift
import FirebaseDatabase


class UserAgreement_VC: UIViewController {

  
   
    @IBOutlet weak var btnTermsCondition: UIButton!
    @IBOutlet weak var btnAccept: UIButton!
 
    let UserDefault = UserDefaults.standard


        override func viewDidLoad() {
            super.viewDidLoad()
            
            
                                      
            btnTermsCondition.setImage(UIImage(named:"square"), for: .normal)
            btnTermsCondition.setImage(UIImage(named:"square2"), for: .selected)
            
            CommonFunctions.shared.makeButtonCornerRounds(button: self.btnAccept , cornerRadius: self.btnAccept.frame.size.height / 2)
            
    }
   
    
       // // // // // // // // // // // // // // //  // // // // // // // // // // // // // // //
      // // // // // // // // // // // // // // //  // // // // // // // // // // // // // // //

    
    
 @IBAction func didPressAcceptAgr(_ sender: UIButton) {
    
    UIView.animate(withDuration: 0.25, delay: 0.1, options: .curveLinear, animations: {
        sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        
    }) { (success) in
        UIView.animate(withDuration: 0.25, delay: 0.1, options: .curveLinear, animations: {
            sender.isSelected = !sender.isSelected
            sender.transform = .identity
        }, completion: nil)
    }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
        
    @IBAction func didPressAccept(_ sender: UIButton) {
        
        if self.btnTermsCondition.isSelected  {
            
            CommonFunctions.shared.saveAgreementAcceptance(value: true)
            UserDefaults.standard.set(true, forKey: "isCheck")
            
            self.navigateToHomeVC()
        }else {
            FTIndicator.showToastMessage(Constants.ErrorMessages.acceptTermsAndConditions)
        }
    }
    
    
    //MARK:- UINavigations
    func navigateToHomeVC(){
        let home_VC = Constants.mainStoryboard.instantiateViewController(withIdentifier: "Home_VC_id") as! HomeViewController
        self.navigationController?.pushViewController(home_VC,animated: true)
    }
    
}


