//
//  UserAgreement_VC.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/2/19.
//  Copyright © 2019 Raphael Fernandez. All rights reserved.
//

import UIKit
import Foundation
import UserNotifications
import CoreBluetooth
import SVProgressHUD
import Toast_Swift

//////////////// UUID's for each of our services//////////////

let bleDeviceServiceCBUUID = CBUUID(string: "71273147-5161-7781-9107-AABBCCDDEEFA")
let batteryServiceUUID = CBUUID(string: "180F")
let tempServiceUUID = CBUUID(string: "1809")
let batteryLevelUUID = CBUUID(string: "2A19")
//let cell2UUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E02")
let co2UUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E04")
let tempUUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E05")
let carbonUUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E06")
let backgroundImageView = UIImageView()
let isMatched = false
let center = UNUserNotificationCenter.current()
let Match_NAME = "ARK"





//////////////// all variables used //////////////


var cell1 = ""
var cell2 = ""
var carSize = ""
var temp = ""
var co2 = ""
var battery = ""
var carbon = "" //String (0xffff)

var cH: UInt16 = 0
var cL: UInt16 = 0
var CarbonHL: UInt16 = 0

var co2H: UInt16 = 0
var co2L: UInt16 = 0
var co2HL: UInt16 = 0



//var decimalString = String(Int(string, radix: 32)!, radix: 10)


var cell1Character: CBCharacteristic?
var cell2Character: CBCharacteristic?
var carSizeCharacter: CBCharacteristic?
var bleDevicePeripheral: CBPeripheral!



class HomeViewController: UIViewController {

    
    let userDefaultDevices = UserDefaults.standard
    
    let transiton = SlideInTransition()
    let backgroundImageView = UIImageView()
    
    let deviceData = UserDefaults.standard
    
    
    var topView: UIView?
    var centralManager: CBCentralManager!
    
    //////// storyboard label variables
    @IBOutlet weak var lblTemperature: UILabel!
    @IBOutlet weak var lblBattery: UILabel!
    @IBOutlet weak var lblCarbon: UILabel!
    @IBOutlet weak var lblPPM: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    var status = 0

    @IBOutlet weak var tempView: UIView!
    @IBOutlet weak var battView: UIView!
    @IBOutlet weak var carbonView: UIView!
    
    
    override func viewDidLoad() {
        
      
        
        super.viewDidLoad()
        
        SVProgressHUD.setDefaultMaskType(.black)
      //  SVProgressHUD.show(withStatus: "Checking state")
        //SVProgressHUD.dismiss(withDelay: 0.4)
        centralManager = CBCentralManager(delegate: self, queue: nil)
        centralManager.delegate = self
        
        createShadow3(view: tempView)
        createShadow3(view: battView)
        createShadow3(view: carbonView)
        
        
    }
    
    
    func createShadow3(view: UIView){
        
        view.layer.shadowColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        view.layer.shadowRadius = 10
        view.layer.shadowOpacity = 0.4
        view.layer.shadowOffset = CGSize(width: 2, height: 2)
        
        view.layer.cornerRadius  = 10
        
    }
    
    

////////// func populateTemperature(temData: [UInt8]){/////////////////
    
    func populateValues(){
        
        if ((deviceData.value(forKey: "data")) != nil){
            // print("Some data already available.")
            
            let data = deviceData.value(forKey: "data") as! [String]
            lblTemperature.text = data[0]
            lblPPM.text = data[1]
            lblBattery.text = data[2]
            lblCarbon.text = data[3]
            
        }else {
            // first time
            
            lblTemperature.text = temp
            lblPPM.text = co2
            lblBattery.text = battery
            lblCarbon.text = carbon
            let data  = [temp, co2, battery, carbon] as Any
            print(data)
            deviceData.set(data, forKey: "data")
        }
        
      
    }
    
    func HexToDecimal(Hex: String) -> Int {
    return Int(Hex, radix: 16) ?? 0
    }
    
    
    
    
//////// buttonn function implementation//////////////////
    
    @IBAction func didTapMenu(_ sender: UIButton) {
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }
    
///////////////////// side nav menu///////////////////////
    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title
        
        topView?.removeFromSuperview()
        
        switch menuType {
            
        case .home:
            let HomeView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Home_VC_id") as! HomeViewController
            HomeView.view.frame = self.view.bounds
            self.view.addSubview(HomeView.view)
            
            
        case .contact:
            let ContactView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Contact") as! ContactViewController
            ContactView.view.frame = self.view.bounds
            self.view.addSubview(ContactView.view)
            //self.topView = view
            
        case .settings:
            let SettingsView = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Settings") as! SettingsViewController
            SettingsView.view.frame = self.view.bounds
            self.view.addSubview(SettingsView.view)
            
         }
    }
}

extension HomeViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}

////////// status bar control status ////////////////////
extension HomeViewController: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
    
        switch central.state {
        case .unknown:
            print("central.state is .unknown")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unknown device")
            break
        case .resetting:
            print("central.state is .resetting")
            SVProgressHUD.dismiss()
            self.view.makeToast("Resetting")
            break
        case .unsupported:
            print("central.state is .unsupported")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unsupported device")
            break
        case .unauthorized:
            print("central.state is .unauthorized")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unauthorized device")
            break
        case .poweredOff:
            print("central.state is .poweredOff")
            
            if !isMatched {
                
                let alertController = UIAlertController(title: "Oops!", message: "Bluetooth is Off", preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(defaultAction)
                
                present(alertController, animated: true, completion: nil)
                
            }
            lblStatus.text = "Bluetooth Off"
            SVProgressHUD.dismiss()
            self.view.makeToast("Power off")
            break
            
        case .poweredOn:
            print("central.state is .poweredOn")
            lblStatus.text = "Bluetooth On"
            SVProgressHUD.show(withStatus: "Scanning")
            self.centralManager.scanForPeripherals(withServices: [bleDeviceServiceCBUUID, batteryServiceUUID, tempServiceUUID])
           
        
            //SVProgressHUD.dismiss(withDelay: 3)
            
//            Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { (_) in
//                SVProgressHUD.dismiss()
//                SVProgressHUD.show()
            
                
            
        }
    }
    
    
    
    
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any], rssi RSSI: NSNumber) {
 
      lblStatus.text = "Scanned"
      SVProgressHUD.dismiss()
      print(peripheral)
      bleDevicePeripheral = peripheral
      bleDevicePeripheral.delegate = self
      //print(bleDevicePeripheral.name as Any)
//        centralManager.stopScan()
//        if let bleDevicePeripheral = bleDevicePeripheral {
//        centralManager.connect(bleDevicePeripheral)
//        }
        

        let device = (advertisementData as NSDictionary).object(forKey: CBAdvertisementDataLocalNameKey)as? NSString


        if device?.contains(Match_NAME) == true {

           //self.centralManager.stopScan()
            let unknown = "Unknowsn"
            let alertController = UIAlertController(title: "Found a Bluetooth!", message: "\(device ?? unknown as NSString)", preferredStyle: .alert)
//            guard let cusotmView = DeviceNameController().view else { return  }
//            alertController.view.addSubview(cusotmView)
            let okAction = UIAlertAction(title: "OK", style: .default)
            { (action) in
              
                self.userDefaultDevices.set(true, forKey: "isDevice")
                
                self.centralManager.stopScan()
                
                if let bleDevicePeripheral = bleDevicePeripheral {
                    // update the value
                    
                    self.centralManager.connect(bleDevicePeripheral)
                  

                }else {
                    print("mUs")
                }



            }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
            { (action) in
                // ...
            }
                alertController.addAction(okAction)
                alertController.addAction(cancelAction)
            if (userDefaultDevices.value(forKey: "isDevice") as? Bool == true){
                // show the data
                self.populateValues()
                
            }else {
                 present(alertController, animated: true, completion: nil)
            }
            
          }
}
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected!")
        lblStatus.text = "Connected!"
        bleDevicePeripheral?.discoverServices([batteryServiceUUID,  bleDeviceServiceCBUUID])
        _ = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { (timer) in
            bleDevicePeripheral?.discoverServices([batteryServiceUUID,  bleDeviceServiceCBUUID])
        }
    }
}

extension HomeViewController: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { return }
        lblStatus.text = "Service discovered!"
        //        SVProgressHUD.show(withStatus: "Discovering Characteristics")
        for service in services {
            print(service)
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics else { return }
        lblStatus.text = "Characteristics discovered"
        //        SVProgressHUD.dismiss()
        for characteristic in characteristics {
            print(characteristic)
            
            //   peripheral.readValue(for: characteristic)
            //    peripheral.setNotifyValue(true, for: characteristic)
            if characteristic.properties.contains(.read) {
                print("\(characteristic.uuid): properties contains .read")
                peripheral.readValue(for: characteristic)
            }
            if characteristic.properties.contains(.notify) {
                print("\(characteristic.uuid): properties contains .notify")
                peripheral.setNotifyValue(true, for: characteristic)
                peripheral.readValue(for: characteristic)
            }
            if characteristic.properties.contains(.indicate){
                print("\(characteristic.uuid): properties contains .indicate")
                peripheral.readValue(for: characteristic)
            }
        }
    }
    
    //////// status bar ///////////
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        lblStatus.text = "Value updated"
        
        var returnValues : [UInt8]?{
            didSet{
               //print(returnValues[0])
                 battery = "\(battery)\(Int(returnValues![0])) %"
                self.populateValues()
                //updateValues(returnedValue: returnValues, characteristic: characteristic)
            }
        }
        
//        if characteristic.value != nil{
//
//            returnValues = [UInt8](characteristic.value!)
//        }
//
        
        if let value = characteristic.value{
            returnValues = [UInt8](value)
            
        }
        
       
        
        
      
    }
    
    
    
    // update values
    
    fileprivate func updateValues(returnedValue: [UInt8]?, characteristic: CBCharacteristic?){
        
        guard let characteristic = characteristic else { return }
        
        switch characteristic.uuid {
            
            
        case batteryLevelUUID:
            guard let returnValues = returnedValue else { return }
            battery = ""
            for i in 0 ..< returnValues.count{
                
                battery = "\(battery)\(Int(returnValues[i])) %"
                
            }
            
        case tempUUID:
            guard let returnValues = returnedValue else { return }
            temp = ""
            for i in 0 ..< returnValues.count{
                temp = "\(temp)\(Int(returnValues[i])) °F"
            }
            
        case co2UUID:
            guard let returnValues = returnedValue else { return }
            if characteristic.value != nil{
                
                co2H = UInt16(returnValues[0])
                co2L = UInt16(returnValues[1])
                co2HL = ( co2H << 8 ) | co2L
                co2 = String (co2HL)
                
            }
            
            
            
        case carbonUUID:
            guard let returnValues = returnedValue else { return }
            cH = UInt16(returnValues[0])
            cL = UInt16(returnValues[1])
            CarbonHL = ( cH << 8 ) | cL
            carbon = String (CarbonHL)
            
            
            
            
        default:
            print("Unhandled Characteristic UUID: \(characteristic.uuid)")
        }
        self.populateValues()
        
    }
    
    
    
    
    
    
    
    
    
    

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        lblStatus.text = "Value updated"
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        print("\(characteristic.uuid), \(String(describing: error))")
    }
}

