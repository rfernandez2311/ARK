//
//  UserAgreement_VC.swift
//  ARK
//
//  Created by Raphael Fernandez Gonzalez on 8/2/19.
//  Copyright © 2019 Raphael Fernandez. All rights reserved.
//

import UIKit
import Foundation
import UserNotifications
import CoreBluetooth
import SVProgressHUD
import Toast_Swift

//////////////// UUID's for each of our services//////////////

let bleDeviceServiceCBUUID = CBUUID(string: "71273147-5161-7781-9107-AABBCCDDEEFA")
let batteryServiceUUID = CBUUID(string: "180F")
let tempServiceUUID = CBUUID(string: "1809")
let batteryLevelUUID = CBUUID(string: "2A19")
//let cell2UUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E02")
let co2UUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E04")
let tempUUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E05")
let carbonUUID = CBUUID(string: "01020304-0506-0708-0900-0A0B0C0D0E06")
let backgroundImageView = UIImageView()
let isMatched = false
let center = UNUserNotificationCenter.current()






//////////////// all variables used //////////////


var cell1 = ""
var cell2 = ""
var carSize = ""
var temp = ""
var co2 = ""
var battery = ""
var carbon = "" //String (0xffff)

var cH: UInt16 = 0
var cL: UInt16 = 0
var CarbonHL: UInt16 = 0

var co2H: UInt16 = 0
var co2L: UInt16 = 0
var co2HL: UInt16 = 0



//var decimalString = String(Int(string, radix: 32)!, radix: 10)


var cell1Character: CBCharacteristic?
var cell2Character: CBCharacteristic?
var carSizeCharacter: CBCharacteristic?
var bleDevicePeripheral: CBPeripheral!



class HomeViewController: UIViewController {

    let transiton = SlideInTransition()
    let backgroundImageView = UIImageView()
 
    
    
    var topView: UIView?
    var centralManager: CBCentralManager!
    
    //////// storyboard label variables
    @IBOutlet weak var lblTemperature: UILabel!
    @IBOutlet weak var lblBattery: UILabel!
    @IBOutlet weak var lblCarbon: UILabel!
    @IBOutlet weak var lblPPM: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    var status = 0

    
    
    override func viewDidLoad() {
        
        setBackground() // set the static background
        
        super.viewDidLoad()
        
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.show(withStatus: "Checking state")
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
    }
    
        
    
//////// set the background for the homeviewcontroller/////////////
    
    func setBackground(){
        view.addSubview(backgroundImageView)
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        backgroundImageView.image = UIImage(named: "background2")
        view.sendSubviewToBack(backgroundImageView)
        
    }
    

////////// func populateTemperature(temData: [UInt8]){/////////////////
    
    func populateValues(){
        
        lblTemperature.text = temp
        lblPPM.text = co2
        lblBattery.text = battery
        lblCarbon.text = carbon
        
    }
    
    func HexToDecimal(Hex: String) -> Int {
    return Int(Hex, radix: 16) ?? 0
    }
    
    
    
    
//////// buttonn function implementation//////////////////
    
    @IBAction func didTapMenu(_ sender: UIButton) {
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }

    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title

        topView?.removeFromSuperview()
        switch menuType {
        case .contact:
            let settingsVC = Settings_VC()
            view.addSubview(settingsVC.view)
            self.topView = settingsVC.view
            addChild(settingsVC)
            
        case .settings:
            let view = UIView()
            view.backgroundColor = .blue
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
        default:
            break
        }
    }
}

extension HomeViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}

////////// status bar control status ////////////////////
extension HomeViewController: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .unknown:
            print("central.state is .unknown")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unknown device")
        case .resetting:
            print("central.state is .resetting")
            SVProgressHUD.dismiss()
            self.view.makeToast("Resetting")
        case .unsupported:
            print("central.state is .unsupported")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unsupported device")
        case .unauthorized:
            print("central.state is .unauthorized")
            SVProgressHUD.dismiss()
            self.view.makeToast("Unauthorized device")
        case .poweredOff:
            print("central.state is .poweredOff")
            
            if !isMatched {
                
                let alertController = UIAlertController(title: "Oops!", message: "Bluetooth is Off", preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(defaultAction)
                
                present(alertController, animated: true, completion: nil)
                
            }
            lblStatus.text = "Bluetooth Off"
            SVProgressHUD.dismiss()
            self.view.makeToast("Power off")
            
        case .poweredOn:
            print("central.state is .poweredOn")
            lblStatus.text = "Bluetooth On"
            SVProgressHUD.show(withStatus: "Scanning")
            self.centralManager.scanForPeripherals(withServices: [bleDeviceServiceCBUUID, batteryServiceUUID, tempServiceUUID])
            
        }
    }
    
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any], rssi RSSI: NSNumber) {
        lblStatus.text = "Scanned"
        SVProgressHUD.dismiss()
        print(peripheral)
        bleDevicePeripheral = peripheral
        bleDevicePeripheral.delegate = self
        centralManager.stopScan()
        centralManager.connect(bleDevicePeripheral)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected!")
        lblStatus.text = "Connected!"
        bleDevicePeripheral.discoverServices([batteryServiceUUID,  bleDeviceServiceCBUUID])
        _ = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { (timer) in
            bleDevicePeripheral.discoverServices([batteryServiceUUID,  bleDeviceServiceCBUUID])
        }
    }
}

extension HomeViewController: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { return }
        lblStatus.text = "Service discovered!"
        //        SVProgressHUD.show(withStatus: "Discovering Characteristics")
        for service in services {
            print(service)
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics else { return }
        lblStatus.text = "Characteristics discovered"
        //        SVProgressHUD.dismiss()
        for characteristic in characteristics {
            print(characteristic)
            
            //   peripheral.readValue(for: characteristic)
            //    peripheral.setNotifyValue(true, for: characteristic)
            if characteristic.properties.contains(.read) {
                print("\(characteristic.uuid): properties contains .read")
                peripheral.readValue(for: characteristic)
            }
            if characteristic.properties.contains(.notify) {
                print("\(characteristic.uuid): properties contains .notify")
                peripheral.setNotifyValue(true, for: characteristic)
                peripheral.readValue(for: characteristic)
            }
            if characteristic.properties.contains(.indicate){
                print("\(characteristic.uuid): properties contains .indicate")
                peripheral.readValue(for: characteristic)
            }
        }
    }
    
    //////// status bar ///////////
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        lblStatus.text = "Value updated"
        var returnValues = [UInt8]()
        if characteristic.value != nil{
            returnValues = [UInt8](characteristic.value!)
        }
        
        switch characteristic.uuid {
        case batteryLevelUUID:
            battery = ""
            for i in 0 ..< returnValues.count{
                battery = "\(battery)\(Int(returnValues[i])) %"
                
//                if returnValues.count <  {
//                    
//                    let alertController = UIAlertController(title: "Oops!", message: "Battery is Getting Low", preferredStyle: .alert)
//                    let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
//                    alertController.addAction(defaultAction)
//                    
//                    present(alertController, animated: true, completion: nil)
//                }
            }
            
        case tempUUID:
            temp = ""
            for i in 0 ..< returnValues.count{
                temp = "\(temp)\(Int(returnValues[i])) °F"
            }
            
        case co2UUID:
            
            if characteristic.value != nil{
                
                co2H = UInt16(returnValues[0])
                co2L = UInt16(returnValues[1])
                co2HL = ( co2H << 8 ) | co2L
                co2 = String (co2HL)
                
            } else{
                
                
            }
            
            
            
        case carbonUUID:
           
            cH = UInt16(returnValues[0])
            cL = UInt16(returnValues[1])
            CarbonHL = ( cH << 8 ) | cL
            carbon = String (CarbonHL)
          

            
            
        default:
            print("Unhandled Characteristic UUID: \(characteristic.uuid)")
        }
        self.populateValues()
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        lblStatus.text = "Value updated"
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        print("\(characteristic.uuid), \(String(describing: error))")
    }
}

